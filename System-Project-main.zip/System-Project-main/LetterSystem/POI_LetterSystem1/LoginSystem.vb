﻿Imports System.Data.Odbc
Imports System.Security.Cryptography
Imports System.Text


Public Class Log_in_System
    ' =======================
    ' PRESS ENTER TO LOGIN
    ' =======================
    Private viewForm As ViewDataForm

    Private Sub Login_KeyDown(sender As Object, e As KeyEventArgs)

        If e.KeyCode = Keys.Enter Then
            Loginbutton.PerformClick()
            e.SuppressKeyPress = True
        End If
    End Sub
    ' =======================
    ' HashPassword
    ' =======================
    Private Function HashPassword(input As String) As String
        Using sha256 As SHA256 = SHA256.Create()
            Dim bytes = Encoding.UTF8.GetBytes(input)
            Dim hash = sha256.ComputeHash(bytes)
            Return Convert.ToBase64String(hash)
        End Using
    End Function

    ' =======================
    ' LOGIN BUTTON
    ' =======================
    Private Sub Loginbutton_Click(sender As Object, e As EventArgs) Handles Loginbutton.Click

        Dim enteredUsername As String = User.Text.Trim()
        Dim enteredPassword As String = password.Text.Trim()


        If enteredUsername = "" Or enteredPassword = "" Then
            MessageBox.Show("Please enter username and password.", "Login Failed",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim connectionString As String =
    "Driver={MySQL ODBC 8.0 Unicode Driver};" &
    "Server=192.168.0.187;" &
    "Database=vbdemo;" &
    "User=orofan;" &
    "Password=orofan.com;" &
    "Port=3306;"

        Dim sql As String =
    "SELECT COUNT(*) FROM users WHERE username = ? AND password = ?"

        Using conn As New OdbcConnection(connectionString)
            Using cmd As New OdbcCommand(sql, conn)

                cmd.Parameters.AddWithValue("?", enteredUsername)
                cmd.Parameters.AddWithValue("?", enteredPassword)


                Try
                    conn.Open()
                    Dim result As Integer = Convert.ToInt32(cmd.ExecuteScalar())

                    If result > 0 Then
                        MessageBox.Show("Login Successful!",
                                    "Success",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Information)

                        Me.DialogResult = DialogResult.OK
                        Me.Close()
                    Else
                        MessageBox.Show("Invalid username or password.",
                                    "Login Failed",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Warning)
                        password.Clear()
                        password.Focus()
                    End If

                Catch ex As Exception
                    MessageBox.Show("Error: " & ex.Message,
                                "Database Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error)
                End Try

            End Using
        End Using

    End Sub
    ' =======================
    ' Load User Name
    ' =======================
    Private Sub LoadUsernames()

        Dim connectionString As String =
        "Driver={MySQL ODBC 8.0 Unicode Driver};" &
        "Server=192.168.0.187;" &
        "Database=vbdemo;" &
        "User=orofan;" &
        "Password=orofan.com;" &
        "Port=3306;"

        Dim sql As String = "SELECT username FROM users"

        Dim autoSource As New AutoCompleteStringCollection()

        Using conn As New OdbcConnection(connectionString)
            Using cmd As New OdbcCommand(sql, conn)

                Try
                    conn.Open()
                    Dim reader As OdbcDataReader = cmd.ExecuteReader()

                    While reader.Read()
                        autoSource.Add(reader("username").ToString())
                    End While

                    reader.Close()

                    User.AutoCompleteCustomSource = autoSource

                Catch ex As Exception
                    MessageBox.Show("Error loading usernames: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub

    Private Sub User_GotFocus(sender As Object, e As EventArgs) Handles User.GotFocus
        If User.Text = "Username" Then
            User.Text = ""
            User.ForeColor = Color.Black
        End If
    End Sub

    Private Sub User_LostFocus(sender As Object, e As EventArgs) Handles User.LostFocus
        If User.Text = "" Then
            User.Text = "Username"
            User.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub password_Enter(sender As Object, e As EventArgs) Handles password.Enter

        If password.Text = "Password" Then
            password.Text = ""
            password.ForeColor = Color.Black

            password.UseSystemPasswordChar = Not chkShowPassword.Checked
        End If

    End Sub


    Private Sub password_Leave(sender As Object, e As EventArgs) Handles password.Leave

        If password.Text = "" Then
            password.UseSystemPasswordChar = False
            password.Text = "Password"
            password.ForeColor = Color.DarkGray
        End If

    End Sub
    ' =======================
    ' Login sts
    ' =======================
    Private Sub Log_in_System_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        User.Text = "Username"
        User.ForeColor = Color.DarkGray

        password.Text = "Password"
        password.ForeColor = Color.DarkGray
        password.UseSystemPasswordChar = False

        ' 🔥 Enable AutoComplete
        User.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        User.AutoCompleteSource = AutoCompleteSource.CustomSource

        LoadUsernames() ' call function
    End Sub

    '
    Private Sub chkShowPassword_CheckedChanged(sender As Object, e As EventArgs) Handles chkShowPassword.CheckedChanged

        ' Do nothing if placeholder is showing
        If password.Text = "Password" Then Exit Sub

        password.UseSystemPasswordChar = Not chkShowPassword.Checked

    End Sub
    ' =======================
    ' Login sts
    ' =======================
    Private Sub btnViewData_Click(sender As Object, e As EventArgs) Handles btnViewData.Click

        If viewForm Is Nothing OrElse viewForm.IsDisposed Then
            viewForm = New ViewDataForm()
            viewForm.Show()
        Else
            viewForm.BringToFront()
            viewForm.Focus()
        End If

    End Sub



End Class

﻿Public Class CutsceneForm

    Private Sub CutsceneForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Make the form fullscreen
        Me.FormBorderStyle = FormBorderStyle.None
        Me.WindowState = FormWindowState.Maximized
        Me.TopMost = True
        Me.BackColor = Color.Black

        ' Configure the PictureBox
        picCutscene.Dock = DockStyle.Fill
        picCutscene.SizeMode = PictureBoxSizeMode.Zoom

        ' Load the GIF
        picCutscene.Image = Image.FromFile("idle.gif")
    End Sub

    ' Close on mouse movement
    Private Sub CutsceneForm_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Me.Close()
    End Sub

    ' Close on any key press
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        Me.Close()
        Return True
    End Function

End Class

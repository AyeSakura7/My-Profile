﻿Imports System.Data.Odbc

Public Class ViewDataForm

    ' =======================
    ' DATABASE CONNECTION
    ' =======================
    Private ReadOnly connStr As String =
    "Driver={MySQL ODBC 8.0 Unicode Driver};" &
    "Server=192.168.0.187;" &
    "Database=vbdemo;" &
    "User=orofan;" &
    "Password=orofan.com;" &
    "Port=3306;"

    ' =======================
    ' AUTO REFRESH TIMER
    ' =======================
    Private refreshTimer As New Timer()
    Private lastMaxID As Integer = 0

    ' =======================
    ' FORM LOAD
    ' =======================
    Private Sub ViewDataForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        LoadRecords("")

        ' Grid Settings
        ViewData.ReadOnly = True
        ViewData.AllowUserToAddRows = False
        ViewData.AllowUserToDeleteRows = False
        ViewData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        ViewData.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

        ' Style Settings
        ViewData.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(245, 245, 245)

        ViewData.EnableHeadersVisualStyles = False
        ViewData.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(198, 239, 206)
        ViewData.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
        ViewData.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI", 10, FontStyle.Bold)

        ViewData.DefaultCellStyle.Font = New Font("Segoe UI", 9)
        ViewData.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 120, 215)
        ViewData.DefaultCellStyle.SelectionForeColor = Color.White
        ViewData.GridColor = Color.LightGray

        'left color
        ViewData.RowHeadersVisible = True
        ViewData.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(198, 239, 206)
        ViewData.RowHeadersDefaultCellStyle.ForeColor = Color.Black

        ' Setup Smart Refresh Timer (10 sec)
        refreshTimer.Interval = 10000
        AddHandler refreshTimer.Tick, AddressOf RefreshTimer_Tick
        refreshTimer.Start()

        ' Initialize search placeholder
        TextBoxSearch.Text = "Search"
        TextBoxSearch.ForeColor = Color.Gray

    End Sub


    ' =======================
    ' SMART AUTO REFRESH
    ' =======================
    Private Sub RefreshTimer_Tick(sender As Object, e As EventArgs)

        Dim sql As String = "SELECT IFNULL(MAX(LogbookID), 0) FROM records"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)
                Try
                    conn.Open()
                    Dim currentMaxID As Integer = Convert.ToInt32(cmd.ExecuteScalar())

                    If currentMaxID > lastMaxID Then
                        LoadRecords(TextBoxSearch.Text.Trim())
                    End If

                Catch
                    ' Silent check (no popup every 10 seconds)
                End Try
            End Using
        End Using

    End Sub


    ' =======================
    ' LOAD RECORDS (WITH SEARCH)
    ' =======================
    Private Sub LoadRecords(keyword As String)

        Dim sql As String =
"SELECT LogbookID, control_no, origin, particulars, date_received, received_by, remarks
 FROM records
 WHERE isArchived = 0
 AND (
        control_no LIKE ?
     OR origin LIKE ?
     OR particulars LIKE ?
     OR received_by LIKE ?
     OR remarks LIKE ?
 )
 ORDER BY LogbookID ASC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Dim searchPattern As String = "%" & keyword & "%"

                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@p1", searchPattern)
                cmd.Parameters.AddWithValue("@p2", searchPattern)
                cmd.Parameters.AddWithValue("@p3", searchPattern)
                cmd.Parameters.AddWithValue("@p4", searchPattern)
                cmd.Parameters.AddWithValue("@p5", searchPattern)

                Try
                    conn.Open()

                    Dim adapter As New OdbcDataAdapter(cmd)
                    Dim table As New DataTable()

                    adapter.Fill(table)

                    ViewData.DataSource = table
                    'record counter
                    lblRecordCount.Text = "Total Records: " & table.Rows.Count.ToString()


                    ' Update latest ID for smart refresh
                    If table.Rows.Count > 0 Then
                        lastMaxID = Convert.ToInt32(table.Rows(table.Rows.Count - 1)("LogbookID"))
                    End If

                Catch ex As Exception
                    MessageBox.Show("Search error: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub


    ' =======================
    ' LIVE SEARCH
    ' =======================
    Private Sub TextBoxSearch_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSearch.TextChanged
        If TextBoxSearch.Text <> "Search" Then
            LoadRecords(TextBoxSearch.Text.Trim())
        End If
    End Sub


    ' =======================
    ' SEARCH PLACEHOLDER
    ' =======================
    Private Sub TextBoxSearch_Enter(sender As Object, e As EventArgs) Handles TextBoxSearch.Enter
        If TextBoxSearch.Text = "Search" Then
            TextBoxSearch.Text = ""
            TextBoxSearch.ForeColor = Color.Black
        End If
    End Sub

    Private Sub TextBoxSearch_Leave(sender As Object, e As EventArgs) Handles TextBoxSearch.Leave
        If TextBoxSearch.Text.Trim() = "" Then
            TextBoxSearch.Text = "Search"
            TextBoxSearch.ForeColor = Color.Gray
        End If
    End Sub


    ' =======================
    ' STOP TIMER WHEN CLOSING
    ' =======================
    Private Sub ViewDataForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        refreshTimer.Stop()
    End Sub

End Class

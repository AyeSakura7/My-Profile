﻿Imports System.Data.Odbc
Imports Microsoft.VisualBasic.Devices

Public Class Archive

    Private Sub Archive_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridArchive.Columns.Clear()
        DataGridArchive.AutoGenerateColumns = False

        DataGridArchive.Columns.Add("LogbookID", "ID")
        DataGridArchive.Columns("LogbookID").Visible = False

        DataGridArchive.Columns.Add("ControlNo", "Control No.")
        DataGridArchive.Columns.Add("OriginDate", "Origin / Date of Letter")
        DataGridArchive.Columns.Add("Particulars", "Particulars")
        DataGridArchive.Columns.Add("DateReceived", "Date Received")
        DataGridArchive.Columns.Add("ReceivedBy", "Received By")
        DataGridArchive.Columns.Add("Remarks", "Remarks")
        LoadArchivedRecords()


        ' Placeholder
        SearchArchive.Text = "Search"
        SearchArchive.ForeColor = Color.Gray

    End Sub

    Private Sub LoadArchivedRecords()

        DataGridArchive.Rows.Clear()

        Dim sql As String =
    "SELECT LogbookID, control_no, origin, particulars, date_received, received_by, remarks
     FROM records
     WHERE isArchived = 1
     ORDER BY LogbookID ASC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Try
                    conn.Open()
                    Using reader As OdbcDataReader = cmd.ExecuteReader()

                        While reader.Read()
                            DataGridArchive.Rows.Add(
                            reader("LogbookID"),
                            reader("control_no").ToString(),
                            reader("origin").ToString(),
                            reader("particulars").ToString(),
                            CDate(reader("date_received")).ToString("yyyy-MM-dd"),
                            reader("received_by").ToString(),
                            reader("remarks").ToString()
                        )
                        End While

                    End Using
                Catch ex As Exception
                    MessageBox.Show("Load error: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub


    Private Sub btnRestore_Click(sender As Object, e As EventArgs) Handles RestoreArchive.Click

        ' Make sure user selected a row
        If DataGridArchive.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select a record to restore.",
                            "No Selection",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Get the selected LogbookID (hidden first column)
        Dim selectedID As Integer =
            Convert.ToInt32(DataGridArchive.SelectedRows(0).Cells(0).Value)

        ' Confirm restore
        If MessageBox.Show("Restore this record?",
                           "Confirm Restore",
                           MessageBoxButtons.YesNo,
                           MessageBoxIcon.Question) <> DialogResult.Yes Then Exit Sub

        ' SQL to restore (soft delete reverse)
        Dim sql As String = "UPDATE records SET isArchived = 0 WHERE LogbookID = ?"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                cmd.Parameters.AddWithValue("@LogbookID", selectedID)

                Try
                    conn.Open()
                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    MessageBox.Show("Restore failed: " & ex.Message,
                                    "Error",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error)
                    Exit Sub
                End Try

            End Using
        End Using

        ' Refresh archive grid
        LoadArchivedRecords()

        MessageBox.Show("Record restored successfully!",
                        "Success",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information)

    End Sub

    Private Sub btnPermanentDelete_Click(sender As Object, e As EventArgs) Handles DeleteArchive.Click

        ' Make sure user selected a row
        If DataGridArchive.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select a record to permanently delete.",
                            "No Selection",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning)
            Exit Sub
        End If

        ' Get selected ID
        Dim selectedID As Integer =
            Convert.ToInt32(DataGridArchive.SelectedRows(0).Cells(0).Value)

        ' Strong warning confirmation
        If MessageBox.Show("This action CANNOT be undone." & vbCrLf &
                           "Are you sure you want to permanently delete this record?",
                           "Permanent Delete Warning",
                           MessageBoxButtons.YesNo,
                           MessageBoxIcon.Warning) <> DialogResult.Yes Then Exit Sub

        Dim sql As String = "DELETE FROM records WHERE LogbookID = ?"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                cmd.Parameters.AddWithValue("@LogbookID", selectedID)

                Try
                    conn.Open()
                    cmd.ExecuteNonQuery()
                Catch ex As Exception
                    MessageBox.Show("Permanent delete failed: " & ex.Message,
                                    "Error",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error)
                    Exit Sub
                End Try

            End Using
        End Using

        ' Refresh Archive list
        LoadArchivedRecords()

        MessageBox.Show("Record permanently deleted.",
                        "Deleted",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information)

    End Sub

    Private Sub SearchArchive_Enter(sender As Object, e As EventArgs) Handles SearchArchive.Enter
        If SearchArchive.Text = "Search" Then
            SearchArchive.Text = ""
            SearchArchive.ForeColor = Color.Black
        End If
    End Sub
    Private Sub SearchArchive_Leave(sender As Object, e As EventArgs) Handles SearchArchive.Leave
        If String.IsNullOrWhiteSpace(SearchArchive.Text) Then
            SearchArchive.Text = "Search"
            SearchArchive.ForeColor = Color.Gray
        End If
    End Sub

    Private Sub InitializeGrid()

        If DataGridArchive.Columns.Count > 0 Then Exit Sub

        DataGridArchive.AutoGenerateColumns = False
        DataGridArchive.AllowUserToDeleteRows = False
        DataGridArchive.Columns.Clear()

        DataGridArchive.Columns.Add("LogbookID", "ID")
        DataGridArchive.Columns("LogbookID").Visible = False

        DataGridArchive.Columns.Add("ControlNo", "Control No.")
        DataGridArchive.Columns.Add("OriginDate", "Origin / Date of Letter")
        DataGridArchive.Columns.Add("Particulars", "Particulars")
        DataGridArchive.Columns.Add("DateReceived", "Date Received")
        DataGridArchive.Columns.Add("ReceivedBy", "Received By")
        DataGridArchive.Columns.Add("Remarks", "Remarks")

    End Sub

    Private Sub SearchArchivedRecords(searchText As String)

        If DataGridArchive.Columns.Count = 0 Then
            InitializeGrid()
        End If

        If String.IsNullOrWhiteSpace(searchText) _
       OrElse searchText = "Search" Then

            LoadArchivedRecords()
            Exit Sub
        End If

        DataGridArchive.Rows.Clear()

        Dim sql As String =
        "SELECT LogbookID, control_no, origin, particulars, date_received, received_by, remarks
         FROM records
         WHERE isArchived = 1
         AND (control_no LIKE ?
              OR origin LIKE ?
              OR particulars LIKE ?
              OR received_by LIKE ?
              OR remarks LIKE ?)
         ORDER BY LogbookID ASC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                For i As Integer = 1 To 5
                    cmd.Parameters.AddWithValue("", "%" & searchText & "%")
                Next

                Try
                    conn.Open()
                    Using reader As OdbcDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            DataGridArchive.Rows.Add(
                            reader("LogbookID"),
                            reader("control_no").ToString(),
                            reader("origin").ToString(),
                            reader("particulars").ToString(),
                            CDate(reader("date_received")).ToString("yyyy-MM-dd"),
                            reader("received_by").ToString(),
                            reader("remarks").ToString()
                        )
                        End While
                    End Using
                Catch ex As Exception
                    MessageBox.Show("Search error: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub

    Private Sub SearchArchive_TextChanged(sender As Object, e As EventArgs) Handles SearchArchive.TextChanged

        If SearchArchive.ForeColor = Color.Gray Then Exit Sub

        If String.IsNullOrWhiteSpace(SearchArchive.Text) Then
            LoadArchivedRecords()
        Else
            SearchArchivedRecords(SearchArchive.Text.Trim())
        End If

    End Sub
End Class
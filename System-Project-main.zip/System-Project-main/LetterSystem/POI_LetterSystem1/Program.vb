﻿Imports System.Windows.Forms

Module Program

    <STAThread()>
    Sub Main()

        Application.EnableVisualStyles()
        Application.SetCompatibleTextRenderingDefault(False)

        Dim login As New Log_in_System()

        If login.ShowDialog() = DialogResult.OK Then
            Application.Run(New Form1())
        End If

    End Sub

End Module

﻿Module DatabaseConnection

    Public ReadOnly connStr As String =
        "Driver={MySQL ODBC 8.0 Unicode Driver};" &
        "Server=192.168.0.187;" &
        "Database=vbdemo;" &
        "User=orofan;" &
        "Password=orofan.com;" &
        "Port=3306;"

End Module
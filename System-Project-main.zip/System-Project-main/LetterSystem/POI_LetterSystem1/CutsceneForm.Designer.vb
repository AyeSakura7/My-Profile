﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CutsceneForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.picCutscene = New System.Windows.Forms.PictureBox()
        CType(Me.picCutscene, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'picCutscene
        '
        Me.picCutscene.BackColor = System.Drawing.SystemColors.ControlLight
        Me.picCutscene.Dock = System.Windows.Forms.DockStyle.Fill
        Me.picCutscene.Location = New System.Drawing.Point(0, 0)
        Me.picCutscene.Name = "picCutscene"
        Me.picCutscene.Size = New System.Drawing.Size(800, 450)
        Me.picCutscene.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picCutscene.TabIndex = 0
        Me.picCutscene.TabStop = False
        '
        'CutsceneForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.picCutscene)
        Me.Name = "CutsceneForm"
        Me.Text = "CutsceneForm"
        CType(Me.picCutscene, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents picCutscene As PictureBox
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle9 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle10 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle11 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle12 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Remark = New System.Windows.Forms.Label()
        Me.RecieveBy = New System.Windows.Forms.Label()
        Me.DateTimePickerReceived = New System.Windows.Forms.DateTimePicker()
        Me.DateRecieve = New System.Windows.Forms.Label()
        Me.TextParticulars = New System.Windows.Forms.TextBox()
        Me.Particular = New System.Windows.Forms.Label()
        Me.Origindate = New System.Windows.Forms.Label()
        Me.TextControlno = New System.Windows.Forms.TextBox()
        Me.ControlNo = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.Download = New System.Windows.Forms.Button()
        Me.ToolTip2 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnBackToLogin = New System.Windows.Forms.Button()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextReceivedby = New System.Windows.Forms.TextBox()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel4 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextOrigin = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TableLayoutPanel11 = New System.Windows.Forms.TableLayoutPanel()
        Me.LogBookNumber = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel12 = New System.Windows.Forms.TableLayoutPanel()
        Me.bntedit = New System.Windows.Forms.Button()
        Me.lblEditStatus = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel5 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel7 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel10 = New System.Windows.Forms.TableLayoutPanel()
        Me.TextBoxSearched = New System.Windows.Forms.TextBox()
        Me.TextRemarks = New System.Windows.Forms.RichTextBox()
        Me.TableLayoutPanel9 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.btnMenuToggle = New System.Windows.Forms.Button()
        Me.pnlTopMenu = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel8 = New System.Windows.Forms.TableLayoutPanel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.TableLayoutPanel6 = New System.Windows.Forms.TableLayoutPanel()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.DeleteBrn = New System.Windows.Forms.Button()
        Me.Savebtn = New System.Windows.Forms.Button()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.TableLayoutPanel13 = New System.Windows.Forms.TableLayoutPanel()
        Me.Panel9 = New System.Windows.Forms.Panel()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.TableLayoutPanel4.SuspendLayout()
        Me.TableLayoutPanel11.SuspendLayout()
        Me.TableLayoutPanel12.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.TableLayoutPanel5.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.TableLayoutPanel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.TableLayoutPanel10.SuspendLayout()
        Me.TableLayoutPanel9.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.pnlTopMenu.SuspendLayout()
        Me.TableLayoutPanel8.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.TableLayoutPanel6.SuspendLayout()
        Me.TableLayoutPanel13.SuspendLayout()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FloralWhite
        DataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle9.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle9.SelectionBackColor = System.Drawing.Color.LightPink
        DataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle9
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle10.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.LightPink
        DataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridView1.DefaultCellStyle = DataGridViewCellStyle10
        Me.DataGridView1.Location = New System.Drawing.Point(3, 371)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DataGridView1.MultiSelect = False
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        DataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle11.Font = New System.Drawing.Font("Arial", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.LightPink
        DataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridView1.RowHeadersDefaultCellStyle = DataGridViewCellStyle11
        Me.DataGridView1.RowHeadersWidth = 51
        DataGridViewCellStyle12.ForeColor = System.Drawing.Color.Black
        Me.DataGridView1.RowsDefaultCellStyle = DataGridViewCellStyle12
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView1.Size = New System.Drawing.Size(1918, 682)
        Me.DataGridView1.TabIndex = 1
        '
        'Remark
        '
        Me.Remark.AutoSize = True
        Me.Remark.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Remark.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Remark.Location = New System.Drawing.Point(3, 59)
        Me.Remark.Name = "Remark"
        Me.Remark.Size = New System.Drawing.Size(118, 31)
        Me.Remark.TabIndex = 10
        Me.Remark.Text = "Remarks"
        '
        'RecieveBy
        '
        Me.RecieveBy.AutoSize = True
        Me.RecieveBy.Dock = System.Windows.Forms.DockStyle.Fill
        Me.RecieveBy.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RecieveBy.ForeColor = System.Drawing.SystemColors.Desktop
        Me.RecieveBy.Location = New System.Drawing.Point(3, 0)
        Me.RecieveBy.Name = "RecieveBy"
        Me.RecieveBy.Size = New System.Drawing.Size(517, 47)
        Me.RecieveBy.TabIndex = 8
        Me.RecieveBy.Text = "Received By"
        '
        'DateTimePickerReceived
        '
        Me.DateTimePickerReceived.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DateTimePickerReceived.CalendarMonthBackground = System.Drawing.Color.Gainsboro
        Me.DateTimePickerReceived.CalendarTitleForeColor = System.Drawing.Color.PeachPuff
        Me.DateTimePickerReceived.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateTimePickerReceived.Location = New System.Drawing.Point(200, 177)
        Me.DateTimePickerReceived.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DateTimePickerReceived.Name = "DateTimePickerReceived"
        Me.DateTimePickerReceived.Size = New System.Drawing.Size(515, 35)
        Me.DateTimePickerReceived.TabIndex = 7
        '
        'DateRecieve
        '
        Me.DateRecieve.AutoSize = True
        Me.DateRecieve.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DateRecieve.ForeColor = System.Drawing.SystemColors.Desktop
        Me.DateRecieve.Location = New System.Drawing.Point(3, 175)
        Me.DateRecieve.Name = "DateRecieve"
        Me.DateRecieve.Size = New System.Drawing.Size(122, 32)
        Me.DateRecieve.TabIndex = 6
        Me.DateRecieve.Text = "Date of Received"
        '
        'TextParticulars
        '
        Me.TextParticulars.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextParticulars.BackColor = System.Drawing.Color.Gainsboro
        Me.TextParticulars.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextParticulars.Location = New System.Drawing.Point(3, 210)
        Me.TextParticulars.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextParticulars.Multiline = True
        Me.TextParticulars.Name = "TextParticulars"
        Me.TextParticulars.Size = New System.Drawing.Size(517, 146)
        Me.TextParticulars.TabIndex = 5
        '
        'Particular
        '
        Me.Particular.AutoSize = True
        Me.Particular.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Particular.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Particular.Location = New System.Drawing.Point(3, 176)
        Me.Particular.Name = "Particular"
        Me.Particular.Size = New System.Drawing.Size(136, 31)
        Me.Particular.TabIndex = 4
        Me.Particular.Text = "Particulars"
        '
        'Origindate
        '
        Me.Origindate.AutoSize = True
        Me.Origindate.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Origindate.ForeColor = System.Drawing.SystemColors.Desktop
        Me.Origindate.Location = New System.Drawing.Point(3, 47)
        Me.Origindate.Name = "Origindate"
        Me.Origindate.Size = New System.Drawing.Size(180, 62)
        Me.Origindate.TabIndex = 2
        Me.Origindate.Text = "Origin/Date of Letter"
        '
        'TextControlno
        '
        Me.TextControlno.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextControlno.BackColor = System.Drawing.Color.Gainsboro
        Me.TextControlno.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextControlno.Location = New System.Drawing.Point(200, 2)
        Me.TextControlno.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextControlno.Multiline = True
        Me.TextControlno.Name = "TextControlno"
        Me.TextControlno.Size = New System.Drawing.Size(515, 40)
        Me.TextControlno.TabIndex = 1
        '
        'ControlNo
        '
        Me.ControlNo.AutoSize = True
        Me.ControlNo.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ControlNo.ForeColor = System.Drawing.SystemColors.Desktop
        Me.ControlNo.Location = New System.Drawing.Point(3, 0)
        Me.ControlNo.Name = "ControlNo"
        Me.ControlNo.Size = New System.Drawing.Size(144, 31)
        Me.ControlNo.TabIndex = 0
        Me.ControlNo.Text = "Control No."
        '
        'ToolTip1
        '
        Me.ToolTip1.AutoPopDelay = 3000
        Me.ToolTip1.InitialDelay = 500
        Me.ToolTip1.ReshowDelay = 100
        '
        'Download
        '
        Me.Download.BackColor = System.Drawing.Color.Gainsboro
        Me.Download.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Download.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Download.FlatAppearance.BorderSize = 0
        Me.Download.Font = New System.Drawing.Font("Arial Narrow", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Download.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.Download.Image = CType(resources.GetObject("Download.Image"), System.Drawing.Image)
        Me.Download.Location = New System.Drawing.Point(3, 2)
        Me.Download.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Download.Name = "Download"
        Me.Download.Size = New System.Drawing.Size(176, 72)
        Me.Download.TabIndex = 16
        Me.Download.Text = "Download"
        Me.Download.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ToolTip1.SetToolTip(Me.Download, "Download")
        Me.Download.UseVisualStyleBackColor = False
        '
        'ToolTip2
        '
        Me.ToolTip2.AutoPopDelay = 3000
        Me.ToolTip2.InitialDelay = 500
        Me.ToolTip2.ReshowDelay = 100
        '
        'btnBackToLogin
        '
        Me.btnBackToLogin.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBackToLogin.BackColor = System.Drawing.Color.Gainsboro
        Me.btnBackToLogin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnBackToLogin.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBackToLogin.FlatAppearance.BorderSize = 0
        Me.btnBackToLogin.Font = New System.Drawing.Font("Arial Narrow", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBackToLogin.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.btnBackToLogin.Image = CType(resources.GetObject("btnBackToLogin.Image"), System.Drawing.Image)
        Me.btnBackToLogin.Location = New System.Drawing.Point(3, 154)
        Me.btnBackToLogin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBackToLogin.Name = "btnBackToLogin"
        Me.btnBackToLogin.Size = New System.Drawing.Size(176, 73)
        Me.btnBackToLogin.TabIndex = 18
        Me.btnBackToLogin.Text = "Logout"
        Me.btnBackToLogin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ToolTip2.SetToolTip(Me.btnBackToLogin, "Logout")
        Me.btnBackToLogin.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.Panel1, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.DataGridView1, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 16.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(1924, 1055)
        Me.TableLayoutPanel1.TabIndex = 21
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.TableLayoutPanel2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(3, 2)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(1918, 365)
        Me.Panel1.TabIndex = 22
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 37.75693!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.56926!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.62913!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel2, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel4, 2, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(1918, 365)
        Me.TableLayoutPanel2.TabIndex = 21
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Pink
        Me.Panel2.Controls.Add(Me.TableLayoutPanel3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(727, 2)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(523, 361)
        Me.Panel2.TabIndex = 20
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.BackColor = System.Drawing.Color.Ivory
        Me.TableLayoutPanel3.ColumnCount = 1
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel3.Controls.Add(Me.RecieveBy, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Particular, 0, 2)
        Me.TableLayoutPanel3.Controls.Add(Me.TextParticulars, 0, 3)
        Me.TableLayoutPanel3.Controls.Add(Me.TextReceivedby, 0, 1)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 4
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.16348!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.8811!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.129512!))
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.8259!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(523, 361)
        Me.TableLayoutPanel3.TabIndex = 0
        '
        'TextReceivedby
        '
        Me.TextReceivedby.BackColor = System.Drawing.Color.Gainsboro
        Me.TextReceivedby.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TextReceivedby.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextReceivedby.Location = New System.Drawing.Point(3, 49)
        Me.TextReceivedby.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextReceivedby.Name = "TextReceivedby"
        Me.TextReceivedby.Size = New System.Drawing.Size(517, 40)
        Me.TextReceivedby.TabIndex = 9
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Ivory
        Me.Panel3.Controls.Add(Me.TableLayoutPanel4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 2)
        Me.Panel3.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(718, 361)
        Me.Panel3.TabIndex = 21
        '
        'TableLayoutPanel4
        '
        Me.TableLayoutPanel4.ColumnCount = 2
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 27.45098!))
        Me.TableLayoutPanel4.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 72.54902!))
        Me.TableLayoutPanel4.Controls.Add(Me.ControlNo, 0, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.TextControlno, 1, 0)
        Me.TableLayoutPanel4.Controls.Add(Me.Origindate, 0, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.DateRecieve, 0, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.TextOrigin, 1, 1)
        Me.TableLayoutPanel4.Controls.Add(Me.Label1, 0, 3)
        Me.TableLayoutPanel4.Controls.Add(Me.DateTimePickerReceived, 1, 2)
        Me.TableLayoutPanel4.Controls.Add(Me.TableLayoutPanel11, 1, 3)
        Me.TableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel4.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel4.Name = "TableLayoutPanel4"
        Me.TableLayoutPanel4.RowCount = 4
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.16348!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.66879!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.129512!))
        Me.TableLayoutPanel4.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 42.46284!))
        Me.TableLayoutPanel4.Size = New System.Drawing.Size(718, 361)
        Me.TableLayoutPanel4.TabIndex = 0
        '
        'TextOrigin
        '
        Me.TextOrigin.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextOrigin.BackColor = System.Drawing.Color.Gainsboro
        Me.TextOrigin.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextOrigin.Location = New System.Drawing.Point(200, 49)
        Me.TextOrigin.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextOrigin.Name = "TextOrigin"
        Me.TextOrigin.Size = New System.Drawing.Size(515, 120)
        Me.TextOrigin.TabIndex = 8
        Me.TextOrigin.Text = ""
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Left Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 13.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 253)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 62)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "LogBookNumber"
        '
        'TableLayoutPanel11
        '
        Me.TableLayoutPanel11.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel11.ColumnCount = 1
        Me.TableLayoutPanel11.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel11.Controls.Add(Me.LogBookNumber, 0, 0)
        Me.TableLayoutPanel11.Controls.Add(Me.TableLayoutPanel12, 0, 1)
        Me.TableLayoutPanel11.Location = New System.Drawing.Point(200, 211)
        Me.TableLayoutPanel11.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TableLayoutPanel11.Name = "TableLayoutPanel11"
        Me.TableLayoutPanel11.RowCount = 2
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 58.03109!))
        Me.TableLayoutPanel11.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 41.96891!))
        Me.TableLayoutPanel11.Size = New System.Drawing.Size(515, 146)
        Me.TableLayoutPanel11.TabIndex = 11
        '
        'LogBookNumber
        '
        Me.LogBookNumber.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.LogBookNumber.BackColor = System.Drawing.Color.Gainsboro
        Me.LogBookNumber.Font = New System.Drawing.Font("Arial", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogBookNumber.Location = New System.Drawing.Point(3, 16)
        Me.LogBookNumber.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.LogBookNumber.Multiline = True
        Me.LogBookNumber.Name = "LogBookNumber"
        Me.LogBookNumber.ReadOnly = True
        Me.LogBookNumber.Size = New System.Drawing.Size(509, 66)
        Me.LogBookNumber.TabIndex = 9
        '
        'TableLayoutPanel12
        '
        Me.TableLayoutPanel12.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel12.ColumnCount = 2
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 76.44444!))
        Me.TableLayoutPanel12.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 23.55556!))
        Me.TableLayoutPanel12.Controls.Add(Me.bntedit, 0, 0)
        Me.TableLayoutPanel12.Controls.Add(Me.lblEditStatus, 1, 0)
        Me.TableLayoutPanel12.Location = New System.Drawing.Point(3, 89)
        Me.TableLayoutPanel12.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.TableLayoutPanel12.Name = "TableLayoutPanel12"
        Me.TableLayoutPanel12.RowCount = 1
        Me.TableLayoutPanel12.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel12.Size = New System.Drawing.Size(225, 52)
        Me.TableLayoutPanel12.TabIndex = 1
        '
        'bntedit
        '
        Me.bntedit.BackColor = System.Drawing.Color.Ivory
        Me.bntedit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.bntedit.Dock = System.Windows.Forms.DockStyle.Fill
        Me.bntedit.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.bntedit.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.bntedit.Image = CType(resources.GetObject("bntedit.Image"), System.Drawing.Image)
        Me.bntedit.Location = New System.Drawing.Point(3, 2)
        Me.bntedit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.bntedit.Name = "bntedit"
        Me.bntedit.Size = New System.Drawing.Size(166, 48)
        Me.bntedit.TabIndex = 2
        Me.bntedit.Text = "Edit"
        Me.bntedit.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage
        Me.bntedit.UseVisualStyleBackColor = False
        '
        'lblEditStatus
        '
        Me.lblEditStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.lblEditStatus.AutoSize = True
        Me.lblEditStatus.Font = New System.Drawing.Font("Arial Narrow", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEditStatus.Location = New System.Drawing.Point(175, 0)
        Me.lblEditStatus.Name = "lblEditStatus"
        Me.lblEditStatus.Size = New System.Drawing.Size(39, 52)
        Me.lblEditStatus.TabIndex = 1
        Me.lblEditStatus.Text = "✓"
        Me.lblEditStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblEditStatus.Visible = False
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.TableLayoutPanel5)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(1256, 2)
        Me.Panel4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(659, 361)
        Me.Panel4.TabIndex = 22
        '
        'TableLayoutPanel5
        '
        Me.TableLayoutPanel5.BackColor = System.Drawing.Color.Ivory
        Me.TableLayoutPanel5.ColumnCount = 1
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel5.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel5.Controls.Add(Me.Panel5, 0, 0)
        Me.TableLayoutPanel5.Controls.Add(Me.Panel6, 0, 1)
        Me.TableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel5.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel5.Name = "TableLayoutPanel5"
        Me.TableLayoutPanel5.RowCount = 2
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 77.15878!))
        Me.TableLayoutPanel5.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.84123!))
        Me.TableLayoutPanel5.Size = New System.Drawing.Size(659, 361)
        Me.TableLayoutPanel5.TabIndex = 19
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.TableLayoutPanel7)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(3, 2)
        Me.Panel5.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(653, 274)
        Me.Panel5.TabIndex = 0
        '
        'TableLayoutPanel7
        '
        Me.TableLayoutPanel7.ColumnCount = 2
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.26347!))
        Me.TableLayoutPanel7.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.73653!))
        Me.TableLayoutPanel7.Controls.Add(Me.Panel8, 0, 0)
        Me.TableLayoutPanel7.Controls.Add(Me.TableLayoutPanel9, 1, 0)
        Me.TableLayoutPanel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel7.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel7.Name = "TableLayoutPanel7"
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 359.0!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 99.99999!))
        Me.TableLayoutPanel7.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 359.0!))
        Me.TableLayoutPanel7.Size = New System.Drawing.Size(653, 274)
        Me.TableLayoutPanel7.TabIndex = 21
        '
        'Panel8
        '
        Me.Panel8.Controls.Add(Me.TableLayoutPanel10)
        Me.Panel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel8.Location = New System.Drawing.Point(3, 2)
        Me.Panel8.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(439, 355)
        Me.Panel8.TabIndex = 21
        '
        'TableLayoutPanel10
        '
        Me.TableLayoutPanel10.ColumnCount = 1
        Me.TableLayoutPanel10.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel10.Controls.Add(Me.TextRemarks, 0, 2)
        Me.TableLayoutPanel10.Controls.Add(Me.Remark, 0, 1)
        Me.TableLayoutPanel10.Controls.Add(Me.TableLayoutPanel13, 0, 0)
        Me.TableLayoutPanel10.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel10.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel10.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel10.Name = "TableLayoutPanel10"
        Me.TableLayoutPanel10.RowCount = 3
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.61972!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.42253!))
        Me.TableLayoutPanel10.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.95775!))
        Me.TableLayoutPanel10.Size = New System.Drawing.Size(439, 355)
        Me.TableLayoutPanel10.TabIndex = 0
        '
        'TextBoxSearched
        '
        Me.TextBoxSearched.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextBoxSearched.BackColor = System.Drawing.Color.Gainsboro
        Me.TextBoxSearched.Font = New System.Drawing.Font("Arial", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBoxSearched.ForeColor = System.Drawing.Color.Gray
        Me.TextBoxSearched.Location = New System.Drawing.Point(47, 2)
        Me.TextBoxSearched.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextBoxSearched.Multiline = True
        Me.TextBoxSearched.Name = "TextBoxSearched"
        Me.TextBoxSearched.Size = New System.Drawing.Size(383, 32)
        Me.TextBoxSearched.TabIndex = 2
        Me.TextBoxSearched.Text = "Search"
        '
        'TextRemarks
        '
        Me.TextRemarks.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TextRemarks.BackColor = System.Drawing.Color.Gainsboro
        Me.TextRemarks.Font = New System.Drawing.Font("Arial", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextRemarks.Location = New System.Drawing.Point(3, 97)
        Me.TextRemarks.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TextRemarks.Name = "TextRemarks"
        Me.TextRemarks.Size = New System.Drawing.Size(433, 172)
        Me.TextRemarks.TabIndex = 21
        Me.TextRemarks.Text = ""
        '
        'TableLayoutPanel9
        '
        Me.TableLayoutPanel9.ColumnCount = 1
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel9.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel9.Controls.Add(Me.Panel7, 0, 0)
        Me.TableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel9.Location = New System.Drawing.Point(448, 2)
        Me.TableLayoutPanel9.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel9.Name = "TableLayoutPanel9"
        Me.TableLayoutPanel9.RowCount = 1
        Me.TableLayoutPanel9.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel9.Size = New System.Drawing.Size(202, 355)
        Me.TableLayoutPanel9.TabIndex = 21
        '
        'Panel7
        '
        Me.Panel7.Controls.Add(Me.btnMenuToggle)
        Me.Panel7.Controls.Add(Me.pnlTopMenu)
        Me.Panel7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel7.Location = New System.Drawing.Point(3, 2)
        Me.Panel7.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(196, 351)
        Me.Panel7.TabIndex = 0
        '
        'btnMenuToggle
        '
        Me.btnMenuToggle.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnMenuToggle.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuToggle.ForeColor = System.Drawing.SystemColors.AppWorkspace
        Me.btnMenuToggle.Location = New System.Drawing.Point(149, 2)
        Me.btnMenuToggle.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnMenuToggle.Name = "btnMenuToggle"
        Me.btnMenuToggle.Size = New System.Drawing.Size(43, 46)
        Me.btnMenuToggle.TabIndex = 19
        Me.btnMenuToggle.Text = "☰" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnMenuToggle.UseVisualStyleBackColor = True
        '
        'pnlTopMenu
        '
        Me.pnlTopMenu.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.pnlTopMenu.Controls.Add(Me.TableLayoutPanel8)
        Me.pnlTopMenu.Location = New System.Drawing.Point(8, 52)
        Me.pnlTopMenu.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.pnlTopMenu.Name = "pnlTopMenu"
        Me.pnlTopMenu.Size = New System.Drawing.Size(184, 231)
        Me.pnlTopMenu.TabIndex = 20
        '
        'TableLayoutPanel8
        '
        Me.TableLayoutPanel8.ColumnCount = 1
        Me.TableLayoutPanel8.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel8.Controls.Add(Me.btnBackToLogin, 0, 2)
        Me.TableLayoutPanel8.Controls.Add(Me.Button4, 0, 1)
        Me.TableLayoutPanel8.Controls.Add(Me.Download, 0, 0)
        Me.TableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel8.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel8.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TableLayoutPanel8.Name = "TableLayoutPanel8"
        Me.TableLayoutPanel8.RowCount = 3
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.36333!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.47335!))
        Me.TableLayoutPanel8.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.16331!))
        Me.TableLayoutPanel8.Size = New System.Drawing.Size(182, 229)
        Me.TableLayoutPanel8.TabIndex = 19
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.Gainsboro
        Me.Button4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Button4.Font = New System.Drawing.Font("Arial Narrow", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(3, 78)
        Me.Button4.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(176, 72)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "Archive"
        Me.Button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.TableLayoutPanel6)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(3, 280)
        Me.Panel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(653, 79)
        Me.Panel6.TabIndex = 1
        '
        'TableLayoutPanel6
        '
        Me.TableLayoutPanel6.ColumnCount = 3
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel6.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333!))
        Me.TableLayoutPanel6.Controls.Add(Me.btnRefresh, 2, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.DeleteBrn, 1, 0)
        Me.TableLayoutPanel6.Controls.Add(Me.Savebtn, 0, 0)
        Me.TableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel6.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel6.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.TableLayoutPanel6.Name = "TableLayoutPanel6"
        Me.TableLayoutPanel6.RowCount = 1
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel6.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel6.Size = New System.Drawing.Size(653, 79)
        Me.TableLayoutPanel6.TabIndex = 0
        '
        'btnRefresh
        '
        Me.btnRefresh.BackColor = System.Drawing.Color.Gainsboro
        Me.btnRefresh.Dock = System.Windows.Forms.DockStyle.Fill
        Me.btnRefresh.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRefresh.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.btnRefresh.Image = CType(resources.GetObject("btnRefresh.Image"), System.Drawing.Image)
        Me.btnRefresh.Location = New System.Drawing.Point(437, 2)
        Me.btnRefresh.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(213, 75)
        Me.btnRefresh.TabIndex = 16
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnRefresh.UseVisualStyleBackColor = False
        '
        'DeleteBrn
        '
        Me.DeleteBrn.BackColor = System.Drawing.Color.Gainsboro
        Me.DeleteBrn.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DeleteBrn.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DeleteBrn.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.DeleteBrn.Image = CType(resources.GetObject("DeleteBrn.Image"), System.Drawing.Image)
        Me.DeleteBrn.Location = New System.Drawing.Point(220, 2)
        Me.DeleteBrn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.DeleteBrn.Name = "DeleteBrn"
        Me.DeleteBrn.Size = New System.Drawing.Size(211, 75)
        Me.DeleteBrn.TabIndex = 13
        Me.DeleteBrn.Text = "Delete"
        Me.DeleteBrn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.DeleteBrn.UseVisualStyleBackColor = False
        '
        'Savebtn
        '
        Me.Savebtn.BackColor = System.Drawing.Color.Gainsboro
        Me.Savebtn.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Savebtn.Font = New System.Drawing.Font("Arial Narrow", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Savebtn.ForeColor = System.Drawing.Color.PaleVioletRed
        Me.Savebtn.Image = CType(resources.GetObject("Savebtn.Image"), System.Drawing.Image)
        Me.Savebtn.Location = New System.Drawing.Point(3, 2)
        Me.Savebtn.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Savebtn.Name = "Savebtn"
        Me.Savebtn.Size = New System.Drawing.Size(211, 75)
        Me.Savebtn.TabIndex = 12
        Me.Savebtn.Text = "Save"
        Me.Savebtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Savebtn.UseVisualStyleBackColor = False
        '
        'TableLayoutPanel13
        '
        Me.TableLayoutPanel13.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel13.ColumnCount = 2
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10.16166!))
        Me.TableLayoutPanel13.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 89.83834!))
        Me.TableLayoutPanel13.Controls.Add(Me.TextBoxSearched, 1, 0)
        Me.TableLayoutPanel13.Controls.Add(Me.Panel9, 0, 0)
        Me.TableLayoutPanel13.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel13.Name = "TableLayoutPanel13"
        Me.TableLayoutPanel13.RowCount = 1
        Me.TableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanel13.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanel13.Size = New System.Drawing.Size(433, 53)
        Me.TableLayoutPanel13.TabIndex = 22
        '
        'Panel9
        '
        Me.Panel9.BackgroundImage = CType(resources.GetObject("Panel9.BackgroundImage"), System.Drawing.Image)
        Me.Panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Panel9.Location = New System.Drawing.Point(3, 3)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(38, 32)
        Me.Panel9.TabIndex = 3
        '
        'Form1
        '
        Me.AcceptButton = Me.Savebtn
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.WhiteSmoke
        Me.ClientSize = New System.Drawing.Size(1924, 1055)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "LOGBOOK_SYSTEM"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.TableLayoutPanel3.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.TableLayoutPanel4.ResumeLayout(False)
        Me.TableLayoutPanel4.PerformLayout()
        Me.TableLayoutPanel11.ResumeLayout(False)
        Me.TableLayoutPanel11.PerformLayout()
        Me.TableLayoutPanel12.ResumeLayout(False)
        Me.TableLayoutPanel12.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.TableLayoutPanel5.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.TableLayoutPanel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.TableLayoutPanel10.ResumeLayout(False)
        Me.TableLayoutPanel10.PerformLayout()
        Me.TableLayoutPanel9.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.pnlTopMenu.ResumeLayout(False)
        Me.TableLayoutPanel8.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.TableLayoutPanel6.ResumeLayout(False)
        Me.TableLayoutPanel13.ResumeLayout(False)
        Me.TableLayoutPanel13.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents DeleteBrn As Button
    Friend WithEvents Savebtn As Button
    Friend WithEvents Remark As Label
    Friend WithEvents RecieveBy As Label
    Friend WithEvents DateTimePickerReceived As DateTimePicker
    Friend WithEvents DateRecieve As Label
    Friend WithEvents TextParticulars As TextBox
    Friend WithEvents Particular As Label
    Friend WithEvents Origindate As Label
    Friend WithEvents TextControlno As TextBox
    Friend WithEvents ControlNo As Label
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents ToolTip2 As ToolTip
    Friend WithEvents btnRefresh As Button
    Friend WithEvents TableLayoutPanel1 As TableLayoutPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents TextRemarks As RichTextBox
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents TableLayoutPanel2 As TableLayoutPanel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents TableLayoutPanel3 As TableLayoutPanel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents TableLayoutPanel4 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel5 As TableLayoutPanel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Panel6 As Panel
    Friend WithEvents TableLayoutPanel6 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel7 As TableLayoutPanel
    Friend WithEvents TextBoxSearched As TextBox
    Friend WithEvents btnMenuToggle As Button
    Friend WithEvents btnBackToLogin As Button
    Friend WithEvents Download As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents TableLayoutPanel8 As TableLayoutPanel
    Friend WithEvents TableLayoutPanel9 As TableLayoutPanel
    Friend WithEvents Panel7 As Panel
    Friend WithEvents pnlTopMenu As Panel
    Friend WithEvents Panel8 As Panel
    Friend WithEvents TableLayoutPanel10 As TableLayoutPanel
    Friend WithEvents TextOrigin As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents TableLayoutPanel11 As TableLayoutPanel
    Friend WithEvents LogBookNumber As TextBox
    Friend WithEvents TableLayoutPanel12 As TableLayoutPanel
    Friend WithEvents lblEditStatus As Label
    Friend WithEvents bntedit As Button
    Friend WithEvents TextReceivedby As TextBox
    Friend WithEvents TableLayoutPanel13 As TableLayoutPanel
    Friend WithEvents Panel9 As Panel
End Class

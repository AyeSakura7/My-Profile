﻿Imports System.Data.Odbc

Public Class Form1

    Private menuExpanded As Boolean = False
    Private menuTimer As New Timer()
    Private Const menuMaxHeight As Integer = 150 '120 IS THE MAX HEIGHT OF THE MENU PANEL
    Private Const menuAnimationSpeed As Integer = 10
    Private selectedRowIndex As Integer = -1
    Private allRows As New List(Of Object())

    Dim isEditMode As Boolean = False
    Dim selectedID As Integer



    ' =======================
    ' IDLE CUTSCENE TIMER
    ' =======================
    Private IdleTimer As New Timer()
    Private Const IdleLimit As Integer = 100000000 ' time for cutscene

    ' =======================
    ' DATABASE CONNECTION
    ' =======================
    Private ReadOnly connStr As String =
    "Driver={MySQL ODBC 8.0 Unicode Driver};" &
    "Server=192.168.0.187;" &
    "Database=vbdemo;" &
    "User=orofan;" &
    "Password=orofan.com;" &
    "Port=3306;"

    ' =======================
    ' CONTROL NO GENERATOR
    ' =======================
    Private controlCounter As Integer = 1
    Public controlPrefix As String = "PIO"


    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()

    End Sub

    '=======================
    'toggle menu
    '=======================
    Private Sub btnMenuToggle_Click(sender As Object, e As EventArgs) Handles btnMenuToggle.Click
        menuTimer.Start()

        If menuExpanded Then
            btnMenuToggle.Text = "☰"
        Else
            btnMenuToggle.Text = "✕"
        End If
    End Sub

    Protected Overrides Sub OnMouseDown(e As MouseEventArgs)
        MyBase.OnMouseDown(e)

        ' If click is outside the menu and menu is open → close it
        If menuExpanded AndAlso Not pnlTopMenu.Bounds.Contains(e.Location) Then
            menuTimer.Start()
        End If

    End Sub

    ' =======================
    ' input fileds validation
    ' =======================
    Private Function ValidateInputs() As Boolean

        Dim isValid As Boolean = True

        ' Reset colors first
        TextOrigin.BackColor = Color.White
        TextParticulars.BackColor = Color.White
        TextReceivedby.BackColor = Color.White

        ' Check Origin
        If String.IsNullOrWhiteSpace(TextOrigin.Text) Then
            TextOrigin.BackColor = Color.MistyRose
            isValid = False
        End If

        ' Check Particulars
        If String.IsNullOrWhiteSpace(TextParticulars.Text) Then
            TextParticulars.BackColor = Color.MistyRose
            isValid = False
        End If

        ' Check Received By
        If String.IsNullOrWhiteSpace(TextReceivedby.Text) Then
            TextReceivedby.BackColor = Color.MistyRose
            isValid = False
        End If

        If Not isValid Then
            MessageBox.Show("Please complete all required fields.",
                        "Missing Information",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning)
        End If

        Return isValid

    End Function



    ' =======================
    ' FORM LOAD
    ' =======================
    ' Initialize the form and set up the DataGridView
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        menuTimer.Interval = 10
        AddHandler menuTimer.Tick, AddressOf MenuAnimation

        DataGridView1.Columns.Clear()
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.AllowUserToDeleteRows = False

        DataGridView1.Columns.Add("LogbookID", "ID")
        DataGridView1.Columns("LogbookID").Visible = False ' HIDDEN PK

        DataGridView1.Columns.Add("ControlNo", "Control No.")
        DataGridView1.Columns.Add("OriginDate", "Origin / Date of Letter")
        DataGridView1.Columns.Add("Particulars", "Particulars")
        DataGridView1.Columns.Add("DateReceived", "Date Received")
        DataGridView1.Columns.Add("ReceivedBy", "Received By")
        DataGridView1.Columns.Add("Remarks", "Remarks")

        'Responsive layout
        DataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill

        ' Proportional widths
        DataGridView1.Columns("ControlNo").FillWeight = 15
        DataGridView1.Columns("OriginDate").FillWeight = 20
        DataGridView1.Columns("Particulars").FillWeight = 30
        DataGridView1.Columns("DateReceived").FillWeight = 10
        DataGridView1.Columns("ReceivedBy").FillWeight = 12
        DataGridView1.Columns("Remarks").FillWeight = 25

        'Vertical growth only
        DataGridView1.DefaultCellStyle.WrapMode = DataGridViewTriState.True
        DataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        DataGridView1.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft

        DataGridView1.DefaultCellStyle.Font = New Font("Arial", 10, FontStyle.Bold)
        '===== SELECTION STYLE (KEEP TEXT BLACK) =====
        DataGridView1.DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 199, 206) ' soft pink highlight
        DataGridView1.DefaultCellStyle.SelectionForeColor = Color.Black

        DataGridView1.RowsDefaultCellStyle.SelectionForeColor = Color.Black
        DataGridView1.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.Black

        '===== HEADER COLOR (LIGHT GREEN) =====
        DataGridView1.EnableHeadersVisualStyles = False
        DataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(255, 192, 203)
        DataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
        DataGridView1.ColumnHeadersDefaultCellStyle.Font = New Font("Arial", 15, FontStyle.Bold)

        '===== LEFT EMPTY CELL (ROW HEADER) COLOR =====
        DataGridView1.RowHeadersVisible = True
        DataGridView1.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(255, 192, 203)
        DataGridView1.RowHeadersDefaultCellStyle.ForeColor = Color.Black

        DataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        DataGridView1.MultiSelect = True


        'textcontrolPrefix.ReadOnly = True
        TextControlno.TabStop = False

        DateTimePickerReceived.Value = Date.Today

        InitializeGrid()
        LoadRecordsFromDatabase()
        SyncNextControlNoFromDatabase()
        LoadReceivedByAutoComplete()
        ApplyHoverToAllButtons(Me)
        LoadLastLogBookNumber()

        'Start idle timer
        IdleTimer.Interval = IdleLimit
        AddHandler IdleTimer.Tick, AddressOf IdleTimer_Tick
        IdleTimer.Start()
        pnlTopMenu.Height = 0
        menuExpanded = False
    End Sub



    Private Sub MenuAnimation(sender As Object, e As EventArgs)

        Dim stepSize As Integer = Math.Max(2, (menuMaxHeight - pnlTopMenu.Height) \ 5) '2 AND 5

        If Not menuExpanded Then

            pnlTopMenu.Height += stepSize

            If pnlTopMenu.Height >= menuMaxHeight Then
                pnlTopMenu.Height = menuMaxHeight
                menuTimer.Stop()
                menuExpanded = True
            End If

        Else

            pnlTopMenu.Height -= stepSize

            If pnlTopMenu.Height <= 0 Then
                pnlTopMenu.Height = 0
                menuTimer.Stop()
                menuExpanded = False
            End If

        End If

    End Sub

    ' =======================
    ' LOAD RECORDS (DATABASE)
    ' =======================
    Private Sub LoadRecordsFromDatabase()

        If DataGridView1.Columns.Count = 0 Then
            InitializeGrid()
        End If

        DataGridView1.Rows.Clear()
        allRows.Clear()

        Dim sql As String =
"SELECT LogbookID, control_no, LogBookNumber, origin, particulars, date_received, received_by, remarks
 FROM records
 WHERE isArchived = 0
 ORDER BY LogbookID DESC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Try
                    conn.Open()

                    Using reader As OdbcDataReader = cmd.ExecuteReader()

                        While reader.Read()

                            Dim rowData As Object() = {
                            reader("LogbookID"),
                            reader("control_no").ToString(),
                            reader("origin").ToString(),
                            reader("particulars").ToString(),
                            CDate(reader("date_received")).ToString("yyyy-MM-dd"),
                            reader("received_by").ToString(),
                            reader("remarks").ToString()
                        }

                            DataGridView1.Rows.Add(rowData)
                            allRows.Add(rowData)

                        End While

                    End Using

                Catch ex As Exception
                    MessageBox.Show("Load error: " & ex.Message, "Error")
                End Try

            End Using
        End Using

        SyncNextControlNoFromDatabase()

    End Sub


    ' =======================
    ' GENERATE CONTROL NO
    ' =======================
    Private Sub GenerateNextControlNo()

        Dim currentYear As String = Date.Now.Year.ToString()

        TextControlno.Text = $"{controlPrefix}-{controlCounter.ToString("0000")}-{currentYear}"

    End Sub

    ' =======================
    ' SAVE (DATABASE + GRID)
    ' =======================
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Savebtn.Click

        If Not ValidateInputs() Then Exit Sub

        Using conn As New OdbcConnection(connStr)
            conn.Open()

            Dim sql As String

            If isEditMode Then

                sql = "UPDATE records SET " &
      "LogBookNumber=?, origin=?, particulars=?, date_received=?, received_by=?, remarks=? " &
      "WHERE LogbookID=?"

                Using cmd As New OdbcCommand(sql, conn)


                    cmd.Parameters.AddWithValue("", LogBookNumber.Text.Trim())
                    cmd.Parameters.AddWithValue("", TextOrigin.Text.Trim())
                    cmd.Parameters.AddWithValue("", TextParticulars.Text.Trim())
                    cmd.Parameters.AddWithValue("", DateTimePickerReceived.Value)
                    cmd.Parameters.AddWithValue("", TextReceivedby.Text.Trim())
                    cmd.Parameters.AddWithValue("", TextRemarks.Text.Trim())
                    cmd.Parameters.AddWithValue("", selectedID) ' <-- THIS IS THE FIX

                    Dim rowsAffected = cmd.ExecuteNonQuery()
                    MessageBox.Show("Rows updated: " & rowsAffected)

                End Using

                isEditMode = False

            Else


                '🟢 INSERT MODE
                If IsDuplicateRecord() Then
                    MessageBox.Show("This record already exists. Duplicate entries are not allowed.",
                                "Duplicate Detected",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning)
                    Exit Sub
                End If

                sql = "INSERT INTO records " &
"(LogBookNumber, origin, particulars, date_received, received_by, remarks) " &
"VALUES (?, ?, ?, ?, ?, ?)"

                Using cmd As New OdbcCommand(sql, conn)

                    cmd.Parameters.AddWithValue("@LogBookNumber", LogBookNumber.Text.Trim())
                    cmd.Parameters.AddWithValue("@origin", TextOrigin.Text.Trim())
                    cmd.Parameters.AddWithValue("@particulars", TextParticulars.Text.Trim())
                    cmd.Parameters.AddWithValue("@date_received", DateTimePickerReceived.Value)
                    cmd.Parameters.AddWithValue("@received_by", TextReceivedby.Text.Trim())
                    cmd.Parameters.AddWithValue("@remarks", TextRemarks.Text.Trim())

                    cmd.ExecuteNonQuery()
                    ' Get generated LogbookID
                    Dim getIDCmd As New OdbcCommand("SELECT LAST_INSERT_ID()", conn)
                    Dim newID As Integer = Convert.ToInt32(getIDCmd.ExecuteScalar())

                    ' Sync correct yearly counter
                    SyncNextControlNoFromDatabase()

                    Dim formattedControlNo As String = TextControlno.Text

                    Dim updateSql As String = "UPDATE records SET control_no=? WHERE LogbookID=?"

                    Using updateCmd As New OdbcCommand(updateSql, conn)
                        updateCmd.Parameters.AddWithValue("", formattedControlNo)
                        updateCmd.Parameters.AddWithValue("", newID)
                        updateCmd.ExecuteNonQuery()
                    End Using


                End Using

            End If
        End Using

        LoadRecordsFromDatabase()
        'sync here for control_nu
        ClearFields()
        LoadReceivedByAutoComplete()

    End Sub

    Private Sub SyncNextControlNoFromDatabase()

        Dim currentYear As String = Date.Now.Year.ToString()

        Dim sql As String =
    "SELECT IFNULL(MAX(CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(control_no,'-',2),'-',-1) AS UNSIGNED)),0) + 1 
     FROM records 
     WHERE control_no LIKE ?"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                ' FIXED PATTERN
                cmd.Parameters.AddWithValue("", controlPrefix & "-%-" & currentYear)

                conn.Open()
                controlCounter = Convert.ToInt32(cmd.ExecuteScalar())

            End Using
        End Using

        GenerateNextControlNo()

    End Sub

    Private Sub DataGridView1_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellDoubleClick

        If e.RowIndex < 0 Then Exit Sub

        Dim result As DialogResult = MessageBox.Show(
        "Do you want to load this record for editing?",
        "Load Record",
        MessageBoxButtons.YesNo,
        MessageBoxIcon.Question)

        If result <> DialogResult.Yes Then Exit Sub

        Dim row As DataGridViewRow = DataGridView1.Rows(e.RowIndex)

        '===== SAFELY GET ID =====
        If row.Cells("LogbookID").Value IsNot Nothing Then
            selectedID = Convert.ToInt32(row.Cells("LogbookID").Value)
        End If

        isEditMode = True

        '===== SAFE TEXT LOADING =====
        TextControlno.Text = If(row.Cells(1).Value, "").ToString()
        TextOrigin.Text = If(row.Cells(2).Value, "").ToString()
        TextParticulars.Text = If(row.Cells("Particulars").Value, "").ToString()
        TextReceivedby.Text = If(row.Cells("ReceivedBy").Value, "").ToString()
        TextRemarks.Text = If(row.Cells("Remarks").Value, "").ToString()

        '===== SAFE DATE LOADING =====
        If row.Cells("DateReceived").Value IsNot Nothing Then
            DateTimePickerReceived.Value = Convert.ToDateTime(row.Cells("DateReceived").Value)
        Else
            DateTimePickerReceived.Value = DateTime.Now
        End If
        Dim sql As String = "SELECT LogBookNumber FROM records WHERE LogbookID=?"

        Using conn As New OdbcConnection(connStr)

            conn.Open()

            Using cmd As New OdbcCommand(sql, conn)

                cmd.Parameters.AddWithValue("", selectedID)

                Using reader As OdbcDataReader = cmd.ExecuteReader()

                    If reader.Read() Then
                        LogBookNumber.Text = reader("LogBookNumber").ToString()
                    End If

                End Using

            End Using

        End Using

    End Sub


    '=======================
    'LOAD ROW TO INPUTS
    '=======================

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles DeleteBrn.Click

        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select record(s) first.")
            Exit Sub
        End If

        If MessageBox.Show("Move selected record(s) to Archive?",
                       "Confirm",
                       MessageBoxButtons.YesNo,
                       MessageBoxIcon.Question) <> DialogResult.Yes Then Exit Sub

        Using conn As New OdbcConnection(connStr)
            conn.Open()

            For Each row As DataGridViewRow In DataGridView1.SelectedRows

                Dim logbookID As Integer =
                Convert.ToInt32(row.Cells("LogbookID").Value)

                Dim sql As String =
                "UPDATE records SET isArchived = 1 WHERE LogbookID = ?"

                Using cmd As New OdbcCommand(sql, conn)
                    cmd.Parameters.AddWithValue("", logbookID)
                    cmd.ExecuteNonQuery()
                End Using

            Next
        End Using

        LoadRecordsFromDatabase()
        ClearFields()

        MessageBox.Show("Selected record(s) moved to Archive.")

    End Sub

    Private Sub DataGridView1_KeyDown(sender As Object, e As KeyEventArgs) _
Handles DataGridView1.KeyDown

        If e.KeyCode = Keys.Delete AndAlso DataGridView1.SelectedRows.Count > 0 Then
            e.Handled = True
            e.SuppressKeyPress = True

            ArchiveSelectedRows()   'CALL THE SHARED METHOD
        End If

    End Sub


    Private Sub btnExportExcel_Click(sender As Object, e As EventArgs) _
    Handles Download.Click

        If DataGridView1.Rows.Count = 0 Then
            MessageBox.Show("No data to export.", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If

        Dim saveFile As New SaveFileDialog()
        saveFile.Filter = "Excel Files (*.csv)|*.csv"
        saveFile.Title = "Export to Excel"
        saveFile.FileName = "Records.csv"

        If saveFile.ShowDialog() <> DialogResult.OK Then Exit Sub

        Try
            Using writer As New System.IO.StreamWriter(saveFile.FileName, False, System.Text.Encoding.UTF8)

                'Write headers
                For i As Integer = 0 To DataGridView1.Columns.Count - 1
                    writer.Write(DataGridView1.Columns(i).HeaderText)
                    If i < DataGridView1.Columns.Count - 1 Then writer.Write(",")
                Next
                writer.WriteLine()

                'Write rows
                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.IsNewRow Then Continue For

                    For i As Integer = 0 To DataGridView1.Columns.Count - 1
                        Dim cellValue As String = row.Cells(i).Value?.ToString().Replace(",", " ")
                        writer.Write(cellValue)
                        If i < DataGridView1.Columns.Count - 1 Then writer.Write(",")
                    Next
                    writer.WriteLine()
                Next

            End Using

            MessageBox.Show("Downloaded!", "Export",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception
            MessageBox.Show("Export failed: " & ex.Message, "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub ArchiveSelectedRows()

        If DataGridView1.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select record(s) first.")
            Exit Sub
        End If

        If MessageBox.Show("Move selected record(s) to Archive?",
                       "Confirm",
                       MessageBoxButtons.YesNo,
                       MessageBoxIcon.Question) <> DialogResult.Yes Then Exit Sub

        Using conn As New OdbcConnection(connStr)
            conn.Open()

            For Each row As DataGridViewRow In DataGridView1.SelectedRows

                Dim logbookID As Integer =
                Convert.ToInt32(row.Cells("LogbookID").Value)

                Dim sql As String =
                "UPDATE records SET isArchived = 1 WHERE LogbookID = ?"

                Using cmd As New OdbcCommand(sql, conn)
                    cmd.Parameters.AddWithValue("", logbookID)
                    cmd.ExecuteNonQuery()
                End Using

            Next
        End Using

        LoadRecordsFromDatabase()
        ClearFields()
        DataGridView1.ClearSelection()

        MessageBox.Show("Selected record(s) moved to Archive.")

    End Sub



    '=======================
    'SEARCH
    '=======================
    Private Sub TextBoxSearched_TextChanged(sender As Object, e As EventArgs) _
Handles TextBoxSearched.TextChanged

        Dim keyword As String = TextBoxSearched.Text.Trim()

        'If placeholder or empty → reload all data
        If keyword = "" OrElse keyword = "Search" Then
            LoadRecordsFromDatabase()
            Exit Sub
        End If

        DataGridView1.Rows.Clear()

        Dim sql As String =
    "SELECT LogbookID, control_no, origin, particulars, date_received, received_by, remarks
     FROM records
     WHERE isArchived = 0 AND (
            control_no LIKE ?
         OR origin LIKE ?
         OR particulars LIKE ?
         OR received_by LIKE ?
         OR remarks LIKE ?
     )
     ORDER BY LogbookID ASC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Dim searchPattern As String = "%" & keyword & "%"

                cmd.Parameters.AddWithValue("", searchPattern)
                cmd.Parameters.AddWithValue("", searchPattern)
                cmd.Parameters.AddWithValue("", searchPattern)
                cmd.Parameters.AddWithValue("", searchPattern)
                cmd.Parameters.AddWithValue("", searchPattern)

                conn.Open()

                Using reader As OdbcDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        DataGridView1.Rows.Add(
                        reader("LogbookID"),
                        reader("control_no").ToString(),
                        reader("origin").ToString(),
                        reader("particulars").ToString(),
                        CDate(reader("date_received")).ToString("yyyy-MM-dd"),
                        reader("received_by").ToString(),
                        reader("remarks").ToString()
                    )
                    End While
                End Using
            End Using
        End Using

    End Sub



    '=======================
    'CLEAR INPUTS
    '=======================
    Private Sub ClearFields()

        TextOrigin.Clear()
        TextParticulars.Clear()
        TextReceivedby.Clear()
        TextRemarks.Clear()
        DateTimePickerReceived.Value = Date.Today
    End Sub
    Private Sub LoadLastLogBookNumber()

        Dim sql As String = "SELECT LogBookNumber 
                         FROM records 
                         WHERE LogBookNumber IS NOT NULL 
                         ORDER BY LogbookID DESC 
                         LIMIT 1"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Try
                    conn.Open()

                    Dim result = cmd.ExecuteScalar()

                    If result IsNot Nothing Then
                        LogBookNumber.Text = result.ToString()
                    End If

                Catch ex As Exception
                    MessageBox.Show("Error loading LogBookNumber: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub

    '=======================
    'DUPLICATE CHECK
    '=======================
    Private Function IsDuplicateRecord() As Boolean

        For Each rowData As Object() In allRows
            If rowData(1).ToString().Equals(TextOrigin.Text.Trim(), StringComparison.OrdinalIgnoreCase) AndAlso
               rowData(2).ToString().Equals(TextParticulars.Text.Trim(), StringComparison.OrdinalIgnoreCase) AndAlso
               rowData(3).ToString().Equals(DateTimePickerReceived.Value.ToString("MMMM dd, yyyy")) AndAlso
               rowData(5).ToString().Equals(TextRemarks.Text.Trim(), StringComparison.OrdinalIgnoreCase) Then
                Return True
            End If
        Next

        Return False

    End Function

    '=======================
    'AUTOCOMPLETE FROM DATABASE (RECEIVED BY)
    '=======================
    Private Sub LoadReceivedByAutoComplete()

        Dim ac As New AutoCompleteStringCollection()

        Dim sql As String =
    "SELECT DISTINCT received_by 
     FROM records 
     WHERE received_by IS NOT NULL 
     AND TRIM(received_by) <> ''"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)
                conn.Open()
                Using reader As OdbcDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        ac.Add(reader("received_by").ToString())
                    End While
                End Using
            End Using
        End Using

        TextReceivedby.Multiline = False
        TextReceivedby.AutoSize = False

        'Reset
        TextReceivedby.AutoCompleteCustomSource = Nothing
        TextReceivedby.AutoCompleteMode = AutoCompleteMode.None
        TextReceivedby.AutoCompleteSource = AutoCompleteSource.None

        'Apply autocomplete
        TextReceivedby.AutoCompleteCustomSource = ac
        TextReceivedby.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        TextReceivedby.AutoCompleteSource = AutoCompleteSource.CustomSource

        'Force height AFTER initialization
        Me.BeginInvoke(Sub()
                           TextReceivedby.Height = 30
                       End Sub)

    End Sub

    Private Sub InitializeGrid()

        If DataGridView1.Columns.Count > 0 Then Exit Sub

        DataGridView1.AutoGenerateColumns = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.Columns.Clear()

        DataGridView1.Columns.Add("LogbookID", "ID")
        DataGridView1.Columns("LogbookID").Visible = False

        DataGridView1.Columns.Add("ControlNo", "Control No.")
        DataGridView1.Columns.Add("OriginDate", "Origin / Date of Letter")
        DataGridView1.Columns.Add("Particulars", "Particulars")
        DataGridView1.Columns.Add("DateReceived", "Date Received")
        DataGridView1.Columns.Add("ReceivedBy", "Received By")
        DataGridView1.Columns.Add("Remarks", "Remarks")

    End Sub


    '=======================
    'APPLY COLORED HOVER TO ALL BUTTONS
    '=======================
    Private Sub ApplyHoverToAllButtons(parent As Control)

        For Each ctrl As Control In parent.Controls

            If TypeOf ctrl Is Button Then
                Dim btn As Button = CType(ctrl, Button)

                btn.FlatStyle = FlatStyle.Flat
                btn.UseVisualStyleBackColor = False
                btn.BackColor = Color.White
                btn.Cursor = Cursors.Hand
                btn.FlatAppearance.BorderSize = 1

                '=== COLOR BY BUTTON ===
                Select Case btn.Name

                    Case "Button1" 'SAVE
                        btn.FlatAppearance.MouseOverBackColor = Color.LightGreen
                        btn.FlatAppearance.MouseDownBackColor = Color.Green

                    Case "Button2" 'DELETE
                        btn.FlatAppearance.MouseOverBackColor = Color.LightCoral
                        btn.FlatAppearance.MouseDownBackColor = Color.Red

                    Case "Button3" 'UPDATE
                        btn.FlatAppearance.MouseOverBackColor = Color.LightYellow
                        btn.FlatAppearance.MouseDownBackColor = Color.Gold

                    Case "Button4", "Button5" 'RETRIEVE & DOWNLOAD
                        btn.FlatAppearance.MouseOverBackColor = Color.LightPink
                        btn.FlatAppearance.MouseDownBackColor = Color.HotPink

                End Select

            ElseIf ctrl.HasChildren Then
                ApplyHoverToAllButtons(ctrl)
            End If

        Next

    End Sub

    Private Sub btnBackToLogin_Click(sender As Object, e As EventArgs) Handles btnBackToLogin.Click

        Me.Hide()

        Dim login As New Log_in_System()

        If login.ShowDialog() = DialogResult.OK Then
            Me.Show()

        Else
            Me.Close()
        End If

    End Sub
    ' =======================
    ' IDLE TIMER TRIGGER
    ' =======================
    Private Sub IdleTimer_Tick(sender As Object, e As EventArgs)
        IdleTimer.Stop()

        Using cutscene As New CutsceneForm()
            cutscene.ShowDialog()
        End Using

        ResetIdleTimer()
    End Sub

    ' =======================
    ' RESET IDLE TIMER
    ' =======================
    Private Sub ResetIdleTimer()
        IdleTimer.Stop()
        IdleTimer.Start()
    End Sub

    ' Detect mouse movement
    Private Sub Form1_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        ResetIdleTimer()
    End Sub

    ' Detect keyboard input
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, keyData As Keys) As Boolean
        ResetIdleTimer()
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function


    ' Refreh button
    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click

        TextBoxSearched.Clear()        ' Clear search filter
        LoadRecordsFromDatabase()      ' Reload from database
        LoadReceivedByAutoComplete()   ' Refresh autocomplete
        SyncNextControlNoFromDatabase()
        ClearFields()



    End Sub

    Private Sub TextBoxSearched_Enter(sender As Object, e As EventArgs) Handles TextBoxSearched.Enter
        If TextBoxSearched.Text = "Search" Then
            TextBoxSearched.Text = ""
            TextBoxSearched.ForeColor = Color.Black
        End If

    End Sub
    Private Sub TextBoxSearched_Leave(sender As Object, e As EventArgs) Handles TextBoxSearched.Leave
        If TextBoxSearched.Text = "" Then
            TextBoxSearched.Text = "Search"
            TextBoxSearched.ForeColor = Color.Gray
        End If

    End Sub
    Private Sub btnArchive_Click(sender As Object, e As EventArgs) Handles Button4.Click

        Using archiveForm As New Archive()
            archiveForm.ShowDialog()
        End Using

        ' 🔥 Refresh after closing archive
        LoadRecordsFromDatabase()
        LoadReceivedByAutoComplete()
        SyncNextControlNoFromDatabase()

    End Sub

    Private isCapitalizing As Boolean = False

    Private Sub CapitalizeFirstLetter(txt As TextBoxBase)

        If isCapitalizing Then Exit Sub
        If txt.TextLength = 0 Then Exit Sub

        isCapitalizing = True

        Dim cursorPos As Integer = txt.SelectionStart

        txt.Text = Char.ToUpper(txt.Text(0)) & txt.Text.Substring(1)

        txt.SelectionStart = cursorPos

        isCapitalizing = False

    End Sub

    ' =======================
    ' CAPITALIZED LETTER
    ' =======================

    Private Sub TextParticulars_TextChanged(sender As Object, e As EventArgs) Handles TextParticulars.TextChanged
        CapitalizeFirstLetter(TextParticulars)

    End Sub

    Private Sub TextRemarks_TextChanged(sender As Object, e As EventArgs) Handles TextRemarks.TextChanged
        CapitalizeFirstLetter(TextRemarks)
    End Sub

    Private Sub TextOrigin_TextChanged(sender As Object, e As EventArgs)
        CapitalizeFirstLetter(TextOrigin)
    End Sub

    Private Sub bntedit_Click(sender As Object, e As EventArgs) Handles bntedit.Click
        If LogBookNumber.ReadOnly = True Then
            LogBookNumber.ReadOnly = False
            lblEditStatus.Visible = True
        Else
            LogBookNumber.ReadOnly = True
            lblEditStatus.Visible = False
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub LogBookNumber_TextChanged(sender As Object, e As EventArgs) Handles LogBookNumber.TextChanged

    End Sub
End Class

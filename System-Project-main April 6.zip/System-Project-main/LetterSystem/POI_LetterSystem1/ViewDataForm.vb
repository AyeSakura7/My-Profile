﻿Imports System.Data.Odbc

Public Class ViewDataForm

    ' =======================
    ' DATABASE CONNECTION
    ' =======================
    Private ReadOnly connStr As String =
    "Driver={MySQL ODBC 8.0 Unicode Driver};" &
    "Server=192.168.0.187;" &
    "Database=vbdemo;" &
    "User=orofan;" &
    "Password=orofan.com;" &
    "Port=3306;"

    ' =======================
    ' AUTO REFRESH TIMER
    ' =======================
    Private refreshTimer As New Timer()
    Private lastMaxID As Integer = 0

    ' =======================
    ' FORM LOAD
    ' =======================
    Private Sub ViewDataForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadRecords("")



        ' Vertical growth only
        ViewData.DefaultCellStyle.WrapMode = DataGridViewTriState.True
        ViewData.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells
        ViewData.DefaultCellStyle.Alignment = DataGridViewContentAlignment.TopLeft

        ViewData.DefaultCellStyle.Font = New Font("Segoe UI", 10, FontStyle.Bold)
        ' ===== SELECTION STYLE (KEEP TEXT BLACK) =====
        ViewData.DefaultCellStyle.SelectionBackColor = Color.FromArgb(255, 199, 206) ' soft pink highlight
        ViewData.DefaultCellStyle.SelectionForeColor = Color.Black

        ViewData.RowsDefaultCellStyle.SelectionForeColor = Color.Black
        ViewData.AlternatingRowsDefaultCellStyle.SelectionForeColor = Color.Black

        ' ===== HEADER COLOR (LIGHT GREEN) =====
        ViewData.EnableHeadersVisualStyles = False
        ViewData.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(255, 192, 203)
        ViewData.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black
        ViewData.ColumnHeadersDefaultCellStyle.Font = New Font("Segoe UI", 15, FontStyle.Bold)

        ' ===== LEFT EMPTY CELL (ROW HEADER) COLOR =====
        ViewData.RowHeadersVisible = True
        ViewData.RowHeadersDefaultCellStyle.BackColor = Color.FromArgb(255, 192, 203)
        ViewData.RowHeadersDefaultCellStyle.ForeColor = Color.Black

        ViewData.SelectionMode = DataGridViewSelectionMode.FullRowSelect
        ViewData.MultiSelect = True

        ' Setup Smart Refresh Timer (10 sec)
        refreshTimer.Interval = 10000
        AddHandler refreshTimer.Tick, AddressOf RefreshTimer_Tick
        refreshTimer.Start()

        ' Initialize search placeholder
        TextBoxSearch.Text = "Search"
        TextBoxSearch.ForeColor = Color.Gray

    End Sub


    ' =======================
    ' SMART AUTO REFRESH
    ' =======================
    Private Sub RefreshTimer_Tick(sender As Object, e As EventArgs)

        Dim sql As String = "SELECT IFNULL(MAX(LogbookID), 0) FROM records"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)
                Try
                    conn.Open()
                    Dim currentMaxID As Integer = Convert.ToInt32(cmd.ExecuteScalar())

                    Dim keyword As String = ""

                    If TextBoxSearch.Text <> "Search" Then
                        keyword = TextBoxSearch.Text.Trim()
                    End If

                    LoadRecords(keyword)

                Catch
                    ' Silent check (no popup every 10 seconds)
                End Try
            End Using
        End Using

    End Sub


    ' =======================
    ' LOAD RECORDS (WITH SEARCH)
    ' =======================
    Private Sub LoadRecords(keyword As String)

        ' Save current position
        Dim firstRowIndex As Integer = 0
        Dim selectedID As Integer = -1

        If ViewData.Rows.Count > 0 Then
            firstRowIndex = ViewData.FirstDisplayedScrollingRowIndex

            If ViewData.CurrentRow IsNot Nothing Then
                selectedID = Convert.ToInt32(ViewData.CurrentRow.Cells("LogbookID").Value)
            End If
        End If

        Dim sql As String =
"SELECT LogbookID, control_no, origin, particulars, date_received, received_by, remarks
 FROM records
 WHERE isArchived = 0
 AND (
        control_no LIKE ?
     OR origin LIKE ?
     OR particulars LIKE ?
     OR received_by LIKE ?
     OR remarks LIKE ?
 )
 ORDER BY LogbookID DESC"

        Using conn As New OdbcConnection(connStr)
            Using cmd As New OdbcCommand(sql, conn)

                Dim searchPattern As String = "%" & keyword & "%"

                cmd.Parameters.Clear()
                cmd.Parameters.AddWithValue("@p1", searchPattern)
                cmd.Parameters.AddWithValue("@p2", searchPattern)
                cmd.Parameters.AddWithValue("@p3", searchPattern)
                cmd.Parameters.AddWithValue("@p4", searchPattern)
                cmd.Parameters.AddWithValue("@p5", searchPattern)

                Try
                    conn.Open()

                    Dim adapter As New OdbcDataAdapter(cmd)
                    Dim table As New DataTable()

                    adapter.Fill(table)

                    ViewData.DataSource = table
                    lblRecordCount.Text = "Total Records: " & table.Rows.Count.ToString()

                    ' Restore scroll position
                    If firstRowIndex >= 0 AndAlso firstRowIndex < ViewData.Rows.Count Then
                        ViewData.FirstDisplayedScrollingRowIndex = firstRowIndex
                    End If

                    ' Restore selected row
                    If selectedID <> -1 Then
                        For Each row As DataGridViewRow In ViewData.Rows
                            If Convert.ToInt32(row.Cells("LogbookID").Value) = selectedID Then
                                row.Selected = True
                                ViewData.CurrentCell = row.Cells(1)
                                Exit For
                            End If
                        Next
                    End If

                    ' Update last ID
                    If table.Rows.Count > 0 Then
                        lastMaxID = Convert.ToInt32(table.Rows(table.Rows.Count - 1)("LogbookID"))
                    End If

                Catch ex As Exception
                    MessageBox.Show("Search error: " & ex.Message)
                End Try

            End Using
        End Using

    End Sub


    ' =======================
    ' LIVE SEARCH
    ' =======================
    Private Sub TextBoxSearch_TextChanged(sender As Object, e As EventArgs) Handles TextBoxSearch.TextChanged
        If TextBoxSearch.Text <> "Search" Then
            LoadRecords(TextBoxSearch.Text.Trim())
        End If
    End Sub


    ' =======================
    ' SEARCH PLACEHOLDER
    ' =======================
    Private Sub TextBoxSearch_Enter(sender As Object, e As EventArgs) Handles TextBoxSearch.Enter
        If TextBoxSearch.Text = "Search" Then
            TextBoxSearch.Text = ""
            TextBoxSearch.ForeColor = Color.Black
        End If
    End Sub

    Private Sub TextBoxSearch_Leave(sender As Object, e As EventArgs) Handles TextBoxSearch.Leave
        If TextBoxSearch.Text.Trim() = "" Then
            TextBoxSearch.Text = "Search"
            TextBoxSearch.ForeColor = Color.Gray
        End If
    End Sub


    ' =======================
    ' STOP TIMER WHEN CLOSING
    ' =======================
    Private Sub ViewDataForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        refreshTimer.Stop()
    End Sub

    Private Sub TableLayoutPanel1_Paint(sender As Object, e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub
End Class
